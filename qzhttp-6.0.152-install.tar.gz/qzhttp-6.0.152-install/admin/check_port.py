#!/usr/bin/env python
# encoding: utf8

import sys
import socket
import time

def checkPort(ip, port):
    """check if tcp ip:port is open"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2)
    result = sock.connect_ex((ip, int(port)))
    sock.close()
    return result == 0

if __name__ == "__main__":
    if len(sys.argv) - 1 < 2:
        print >>sys.stderr, "Usage: %s ip port [retry-times]" % sys.argv[0]
        sys.exit(1)
    (ip, port) = sys.argv[1:3]

    if len(sys.argv) -1 == 3:
        retry = int(sys.argv[3])
    else:
        retry = 0

    ok = checkPort(ip, port)
    if ok:
        sys.exit(0)
    for i in range(retry):
        time.sleep(0.5)
        if checkPort(ip, port):
            sys.exit(0)
    sys.exit(1)

