#! /bin/sh

###file_ver=2.0.8

export PATH=$PATH:/usr/bin:/usr/sbin:/sbin:/bin:.

get_config()
{
    if [ "$1" = "" ];then return 1;fi

    conf_file=$dir_pre/../init.xml
    if [ ! -f $conf_file ];then return 1;fi

    conf_value="$dir_pre/../admin/data/tmp/${1}_`date +%s`_$RANDOM"
    
    ## Todo: load config
    row1=`grep -n "^<$1>\$" $conf_file | awk -F: '{print $1}' | tail -n 1`
    row2=`grep -n "^</$1>\$" $conf_file | awk -F: '{print $1}' | tail -n 1`
        
    if [ "$row1" = "" -o "$row2" = "" ];then
        return 1
    fi  
    
    if [ $row1 -gt $row2 ];then
        return 1
    fi  
        
    mkdir -p $dir_pre/../admin/data/tmp/
    head -n `expr $row2 - 1` $conf_file | tail -n `expr $row2 - $row1 - 1` > $conf_value
    ret=$conf_value
    return 0
}

run_config()
{
    get_config $1
    resultcode=$?
    tmp_file=$ret
    if [ $resultcode -eq 0 ];then
        . $tmp_file
        rm $tmp_file > /dev/null 2>&1
    fi
}

run_config "base_info"

#install path
if [ "$install_base" = "" ];then
    install_base="/usr/local/services"
fi

if [ "$install_path" = "" ];then
    if [ -z "$version" ]
    then
        install_path="$install_base/$name"
    else
        install_path="$install_base/$name-$version"
    fi
fi 

if [ "$log_dir" = "" ];then
    log_dir="$install_path/log"
fi

#link dir
link_dir="$HOME/services"
#backup path
backup_path="/data/backup"

if [ "$log_dir" = "" ];then
    log_dir="$install_path/log"
fi

#old version
if [ -L $link_dir/$name ];then
    old_ver=`ls -l $link_dir/$name | awk -F\> '{print $2}'`
else
    old_ver=""
fi

#app count
app_count=`echo "$app_name" | awk '{print NF}'`


#crontab configure
cron_conf="$install_path/admin/data/crontab.conf"
#clear disk configure
g_clear_conf="$install_path/admin/data/clear.conf"
#running file
runing_file="$install_path/admin/data/runing.tmp"

#md5sum result
md5_result="$install_path/admin/data/md5_result.lst"
#md5sum failed
md5_failed="$install_path/admin/data/md5_failed.lst"

ip_outer=`/sbin/ifconfig eth0 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
ip_inner=`/sbin/ifconfig eth1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
if [ "${ip_inner}x" = "x" ];then
   #ip_inner=`/sbin/ip route|grep 'eth1'|grep 'scope link  src'|awk '{print $9}'|head -n 1`
   ip_inner=`/sbin/ip route|egrep 'src 172\.|src 10\.'|awk '{print $9}'|head -n 1`
fi
vip=`/sbin/ifconfig eth1:1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`

#append log to default log device
log_default="$install_path/log/default.log"
log()
{
    if [ "$1" = "" ];then
        return
    fi
    
    echo "[`date '+%Y%m%d %H:%M:%S'`] $*" >> $log_default 2>/dev/null
}

#append log to appointed log device
#parameters:    $1 log device
#               $2 log message
log2()
{
    if [ "$1" = "" ] || [ "$2" = "" ];then
        return
    fi

    echo "[`date '+%Y%m%d %H:%M:%S'`] $2" >> $1 2>/dev/null
}

report()
{
    if [ "$1" = "" ];then
        return
    fi

    expr "$2" : "[0-9]\{1,\}" >/dev/null
    if [ $? -eq 0 ];then
        tmp_port=$2
    else
        tmp_port=$rpt_port
    fi

    log "$1"
    /usr/local/agenttools/agent/agentRepStr $tmp_port "$1"
}

#return boot file path
get_boot_path()
{
    ret="#BOOT_PATH"
}

#get a setting from user
#parameters:    $1 setting name, required
#               $2 default value, optional
#return:            user input, get the value by variable "ret"
get_setting()
{
    default_value=$2
    if [ "$default_value" != "" ];then
        echo -n "Please input $1 [$2] : "
        read ret
        if [ -z $tmp ];then
            ret=$default_value
        fi
        return
    fi
    until [ "$ret" != "" ]
    do
        echo -n "Please input $1 : "
        read ret
    done
}

#create temp file
#parameters:  $1 directory path
#             $2 file prefix
create_tmp_file()
{
    if [ ! -d "${1}" ];then
        mkdir ${1}
        chgrp users ${1}
        chmod 775 ${1}
    fi
    ret=${1}/${2}`date +%Y%m%d%H%M%S%N`.$RANDOM
    while [ -f $ret ]
    do
       sleep 1
       ret=${1}/${2}`date +%Y%m%d%H%M%S%N`.$RANDOM
    done
    touch $ret
    echo $ret
}

#backup file
#parameters:  $1 backup directory path
#             $2 file path
backup_file()
{
    if [ ! -f "$2" ];then return 1;fi

    create_tmp_file $1 `basename $2`.bak > /dev/null
    cp $2 $ret 
}

#convert size to bytes
to_bytes()
{
    size_tmp=`echo "$1" | sed -e "s:[^0-9kKmMgG]::g"`
    if [ "$size_tmp" == "" ];then
        ret=0
        echo $ret
        return
    fi

    expr "$size_tmp" : "[0-9]\{1,\}[kKmMgG]\{0,1\}$" > /dev/null
    if [ $? -ne 0 ];then
        ret=0
        echo $ret
        return
    fi

    size_unit=`echo $size_tmp | sed -e "s:[0-9]::g"`
    size_value=`echo $size_tmp | sed -e "s:[^0-9]::g"`
    if [ "$size_unit" = "k" -o "$size_unit" = "K" ];then
        ret=`expr $size_value '*' 1024`
    elif [ "$size_unit" = "m" -o "$size_unit" = "M" ];then
        ret=`expr $size_value '*' 1024 '*' 1024`
    elif [ "$size_unit" = "g" -o "$size_unit" = "G" ];then
        ret=`expr $size_value '*' 1024 '*' 1024 '*' 1024`
    else
        ret=$size_value
    fi
}

get_proc_num()
{
    local app_name=$1
    
    proc_snapshot=`ps -f -C $app_name | fgrep -w $app_name `
    if [ $? -ne 0 ];then
        proc_snapshot=`pgrep -f '^((\S*/bin/)?(perl|python|php|sh|bash) )?(\S+/)?'$app_name'($| .+$)'`
        if [ $? -ne 0 ];then
            proc_snapshot=`pgrep -f '^java (.*)? (\S+/)?'$app_name'($| .+$)'`
        fi
    fi

    if [ "$proc_snapshot" != "" ];then
        num=`echo "$proc_snapshot" | wc -l`
    else
        num=0
    fi
    
    echo $num
}
