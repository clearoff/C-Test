#!/bin/bash
##################################################
# Note:
# function in this file is kept for compatibility only
# DO NOT USE in new package
###################################################
#PATH was set in pkgadmin.py
export PATH

#common function
function kill_app(){
    local app="$1"
    local signum="$2"
    $install_path/admin/procutil.py kill_app "$app" $signum
}

get_app_num()
{
    numbers=`echo $app_name | sed -e "s:[ \t]:\n:g" | grep "^$1[:$]" | awk -F: '{print $2}'`
    num1=`echo $numbers|awk -F, '{print $1}'`
    num2=`echo $numbers|awk -F, '{print $2}'`

    if [ "${num1}" = "" ];then
        num1=1
    fi

    if [ "${num2}" = "" ];then
        num2=999999999
    fi
    
}

#check_port $ip $port
#return 1 on error and set error_port
#also, check vip:$port
function check_port(){
    local ip="$1"
    local port="$2"
    local retry=2
    local check_cmd="$install_path/admin/check_port.py"
    #check bind ip
    "$check_cmd" "$ip" "$port" "$retry" 
    if [[ $? -ne 0 ]]; then
        #return err_port if no vip
        if [[ -z "$vip" ]]; then
            err_port="$err_port $port"
            return 1 
        fi
        #check vip
        "$check_cmd" "$vip" "$port" "$retry" 
        if [[ $? -ne 0 ]]; then
            err_port="$err_port $port"
            return 1 
        fi
    fi
    return 0
}

#check_process "$app_name"
#return 1 on error and set err_app
function check_process() {
    local ps_cmd="$install_path/admin/procutil.py"
    get_app_num $1
    app=`echo $1 | awk -F: '{print $1}'`
    num=$($ps_cmd get_proc_num "$app")
    if [ $num -lt $num1 -o $num -gt $num2 ];then
        err_app="$err_app $app"
        return 1
    fi
    return 0
}
