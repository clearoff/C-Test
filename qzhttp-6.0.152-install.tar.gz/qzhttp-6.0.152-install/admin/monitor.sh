#!/bin/bash
mydir=$(cd $(dirname "$0") && pwd)
$mydir/pkgadmin.py monitor
