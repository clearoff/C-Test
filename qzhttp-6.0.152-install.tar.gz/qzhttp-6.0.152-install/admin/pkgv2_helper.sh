#!/bin/bash
tmpdir=$(mktemp -d)
SAVEFILE=$(mktemp)
PKG_URL=http://10.166.224.35/createInterface/admin-v2.tgz
BACKUPDIR=/data/backup/pkgadmin
#create backup directory if not exists
[[ -d "$BACKUPDIR" ]] || mkdir -p "$BACKUPDIR"

shopt -s nullglob
function find_all_pkgadmin_dir(){
    shopt -s nullglob
    basedirs="/home/oicq /usr/local/app /usr/local/services"
    for dir in $basedirs; do
        #also consider spp package
        for initxml in $dir/*/init.xml $dir/*/client/init.xml $dir/*/client/*/init.xml; do
            pkgdir=$(dirname $initxml)
            if [[ -d "$pkgdir/admin" ]]; then
                echo "$pkgdir/admin"
            fi
        done
    done
}

function backup_pkgadmin(){
    local admindir=$1
    local backupdir=$2

    if [[ ! -d "$admindir" ]];then
        echo "admindir does not exist or is not directory"
        return 1
    fi
    #replace / with + as file name
    local backupfile=$(dirname $admindir | sed -e 's/\//+/g')
    tar --exclude=data -czf "$backupdir/$backupfile" -C $admindir .
}

function rollback_pkgadmin(){
    local admindir=$1
    local backupdir=$2

    if [[ ! -d "$admindir" ]];then
        echo "admindir does not exist or is not directory"
        return 1
    fi
    #replace / with + as file name
    local backupfile=$(dirname $admindir | sed -e 's/\//+/g')
    if [[ ! -f "$backupdir/$backupfile" ]]; then
        echo "backupfile '$backupfile' not found, abort"
        return 1
    fi
    #remove all existing file
    rm "$admindir"/*.*
    tar -xzf "$backupdir/$backupfile" -C $admindir
}

function update_pkgadmin(){
    local admindir=$1
    local pkgadminfile=$2
    if [[ ! -d "$admindir" ]];then
        echo "admin dir '$admindir' does not exist or is not directory"
        return 1
    fi
    if [[ ! -f "$pkgadminfile" ]];then
        echo "pkgadmin file '$pkgadminfile' does not exist"
        return 1
    fi
    echo "backuping up '$admindir'"
    backup_pkgadmin "$admindir" "$BACKUPDIR"
    if [[ $? -ne 0 ]]; then
        echo "backup '$admindir' failed, abort"
        return 1
    fi
    tar -xzf "$pkgadminfile" -C "$admindir" || return 1
    #get owner from admin dir and set to files in it
    pkg_owner=$(stat -c "%u:%g" "$admindir")
    chown "$pkg_owner" "$admindir"/*.*
}

function cleanup(){
    [[ -f "$SAVEFILE" ]] && rm -f "$SAVEFILE"
    [[ -d "$tmpdir" ]] && rm -rf "$tmpdir"
}

#download pkgadmin from url and save to '$SAVEFILE'
#download_pkgadmin $url
function download_pkgadmin(){
    local fileurl="$1"
    local host="$2"
    echo "downloading pkgadmin file from '$fileurl'"
    if [[ -n "$host" ]]; then
        wget --header "Host: $host" --timeout=3 --quiet --tries=3 $fileurl -O $SAVEFILE
    else
        wget --timeout=3 --quiet --tries=3 $fileurl -O $SAVEFILE
    fi
    if [[ $? -ne 0 ]]; then
        echo "ERROR: pkgadmin download failed"
        rm -f "$SAVEFILE"
        return 1
    fi
    #simple archive integrity check
    tar -xzf $SAVEFILE -C $tmpdir
    if [[ $? -ne 0 ]]; then
        echo "corrupted pkgadmin file, abort"
        return 1
    fi
    if [[ ! -f "$tmpdir/pkgadmin.py" ]]; then
        echo "invalid pkgadmin file, abort"
        return 1
    fi
}

#cleanup tmp file when exit
trap cleanup EXIT

#main
action="$1"
target="$2"
url="$3"
if [[ -z "$target" ]]; then
    echo "Usage: $0 update self|all-pkg [pkgurl]"
    echo "Usage: $0 rollback self|all-pkg"
    exit 1
fi
case "$action" in 
    update)
        pkgurl=${url:=$PKG_URL}
        download_pkgadmin "$pkgurl" "pkg.isd.com" || exit 1
        case "$target" in
            self)
                my_basedir=$(cd $(dirname $0)/../ && pwd)
                framework_dir=$(echo "$my_basedir" | grep -Po '.*/spp_\w+')
                for basedir in $my_basedir $framework_dir; do
                    if [[ -f "$basedir/init.xml" ]] && [[ -d "$basedir/admin" ]]; then
                        #current dir is valid pkg direcotry
                        admindir="$basedir/admin"
                        echo "updating '$admindir'..."
                        update_pkgadmin "$admindir" "$SAVEFILE"
                        if [[ $? -ne 0 ]]; then
                            echo "update '$admindir' failed, rollback"
                            rollback_pkgadmin "$admindir" "$BACKUPDIR"
                            exit 1
                        fi
                    else
                        echo "current dir not in a valid pkg directory"
                        exit 1
                    fi
                done
                ;;
            all-pkg)
                npkg=0
                for admindir in $(find_all_pkgadmin_dir); do
                    (( npkg += 1 ))
                    echo "updating '$admindir'"
                    update_pkgadmin "$admindir" "$SAVEFILE"
                    if [[ $? -ne 0 ]]; then
                        echo "update '$admindir' failed, rollback"
                        rollback_pkgadmin "$admindir" "$BACKUPDIR"
                        exit 1
                    fi
                done
                if (( npkg == 0 )); then
                    echo "no package foud"
                else
                    echo "updated $npkg package"
                fi
                ;;
            *)
                echo "invalid option: $target"
                exit 1
                ;;
        esac
        ;;
    rollback)
        case "$target" in
            self)
                basedir=$(cd $(dirname $0)/../ && pwd)
                if [[ -f "$basedir/init.xml" ]] && [[ -d "$basedir/admin" ]]; then
                    admindir="$basedir/admin"
                    echo "rollback $admindir"
                    rollback_pkgadmin "$admindir" "$BACKUPDIR"
                    if [[ $? -ne 0 ]]; then
                        echo "FAILED"
                        exit 1
                    fi
                else
                    echo "current dir not in a valid pkg directory"
                    exit 1
                fi
                ;;
            all-pkg)
                failed=0
                for admindir in $(find_all_pkgadmin_dir); do
                    echo "rollback $admindir"
                    rollback_pkgadmin "$admindir" "$BACKUPDIR"
                    if [[ $? -ne 0 ]]; then
                        echo "FAILED"
                        (( failed += 1 ))
                    fi
                done
                if (( failed > 0 )); then
                    exit 1
                fi
                ;;
            *)
                echo "invalid option '$target'"
                exit 1
                ;;
        esac
        ;;
    *)
        echo "invalid action: '$action'"
        exit 1
        ;;
esac
#clear special pkg file
rm -f /dev/shm/.pkgadmin.*        
#main

