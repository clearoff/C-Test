#! /usr/bin/env python
# encoding: utf8

import re
import os
import sys
import logging
import subprocess
import signal
import select
import pty
import StringIO
import time
import errno
import socket

from os.path import basename

#change the maxfd of subprocess module for close_fds performance
#our fd is normally small
subprocess.MAXFD = 256

class ProcUtil(object):
    def __init__(self, psSnapshotFile=None):
        self.logger = logging.getLogger(__name__)
        self.psFields = ['pid', 'ppid', 'pcpu', 'rsz','start_time','state','comm', 'args']
        self.scriptRe = re.compile(r'^(bash|sh|perl|python[\d.]*|php|node)$')
        self.commMaxLen = 15
        self.psSnapshotFile = psSnapshotFile
        self.psMap = {}

    def run(self, cmd, input=None, shell="True"):
        """
        run cmd and send cmdinput to its stdin
        output contains both stderr and stdout
        """
        self.logger.debug("run cmd %s", cmd)
        try:
            process = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=shell,
                    bufsize=1, close_fds=True,universal_newlines=True)
            stdout, stderr = process.communicate(input)
            return [process.returncode, stdout]
        except Exception, e:
            self.logger.error("run cmd [%s] error:%s" % (cmd, e), exc_info=True)
            return [1, e]
        
    def interactiveRun(self, cmd, shell="True"):
        """
        run cmd interactive, return [returncode, ""]
        NOTE: output is not captured
        """
        self.logger.debug("run cmd interactively%s", cmd)
        try:
            returncode = subprocess.call(cmd, shell=shell, close_fds=True)
            return [returncode, ""]
        except Exception, e:
            self.logger.error("run cmd [%s] error:%s" % (cmd, e), exc_info=True)
            return [1, e]

    def ptyRun(self, cmd, shell=True, maxBytes=0, pollInterval=0.5, maxDaemonPollTime=10):
        """
        run cmd in pty and return (returncode, output)
        output contains both stderr and stdout

        Note:
        * this will also capture SOME output after process goes to background.
        * keep capturing daemon output if:
          1. there is any output between pollInterval
          2. AND at most maxPollTime after being daemon
        """
        #execute cmd with pty so that output can be discarded when 
        # it goes to background
        #if pty is not available, when use socket pair
        try:
            (master, slave) = pty.openpty()
        except Exception, e:
            self.logger.warn("openpty failed:%s", e)
            #we need to keep a reference to the socket pair
            #otherwise it maybe closed before we use it
            socks = socket.socketpair()
            (master, slave) = [s.fileno() for s in socks]
        self.logger.debug("run cmd %s", cmd)
        try:
            process = subprocess.Popen(cmd, stdout=slave, stderr=slave, shell=shell,
                    bufsize=1, close_fds=True,universal_newlines=True)
        except Exception, e:
            self.logger.error("run cmd [%s] error:%s" % (cmd, e))
            return [1, e]
        
        output = StringIO.StringIO()
        nbytes = 0
        bufsize = 1024
        #roud maxBytes to bufsize
        if maxBytes % bufsize != 0:
            maxBytes = (maxBytes / bufsize + 1) * bufsize 
        processDieTime = 0
        while True:
            rlist, _, _ = select.select([master], [], [], pollInterval)
            if rlist:
                data = os.read(master, bufsize)
                nbytes += len(data)
                if (not maxBytes)  or (nbytes <= maxBytes):
                    output.write(data)

                if process.poll() is None:
                    #process still running
                    continue

                #here process became daemon or terminated
                if not maxDaemonPollTime:
                    #don't want daemon output
                    break
                if not processDieTime:
                    processDieTime = time.time()
                if time.time() - processDieTime > maxDaemonPollTime:
                    self.logger.warning("bad daemon keep writing stdout/stderr")
                    break
            else:
                #no output between pollInterval, check if process terminated
                if process.poll() is not None:
                    #process terminated
                    if maxDaemonPollTime and (not processDieTime):
                        self.logger.info("another loop")
                        #try 1 more loop to capture possible daemon output
                        processDieTime = time.time()
                        continue
                    else:
                        break
        os.close(master)
        os.close(slave)
        self.logger.debug("return code:%d", process.returncode)
        ret = (process.returncode, output.getvalue())
        output.close()
        return ret

    def buildPsMap(self, psSnapshot):
        psMap={}
        lines = psSnapshot.split('\n')
        if len(lines) < 2:
            self.logger.error("invalid ps snapshot")
            return psMap
        self.psTitle = lines.pop(0)
        sep = re.compile(r' +')
        for line in lines:
            line = line.strip()
            if not line:
                break
            fields = sep.split(line, len(self.psFields)-1) 
            (comm, args) = fields[-2:]
            argv = args.split()
            #for script, first arg is intepreter,
            #then the next non-option arg should be script file
            argBin = basename(argv[0])
            if self.scriptRe.match(argBin) and len(argv)>1:
                #skip 'sh -c xxxx', we don't support that
                if argBin == 'sh' and argv[1] == '-c':
                    continue

                #some ugly stupid pkg use python/node as app_name....,
                #in order to keep backaward compatibility with it,
                #we also add interpreter like python/node to psMap
                psMap.setdefault(argBin, []).append(line)

                for arg in argv[1:]:
                    if not arg.startswith('-'):
                        self.logger.debug("got script:%s", args)
                        prog = basename(arg)
                        break
            else:
                # 1. service like nginx and PostgreSQL use setproctitle to change process name,
                #    which modify argv to sth like "nginx: master process", 
                #    and their comm is usually less than commMaxLen. not truncated
                # 2. some service may call prctl to change process name, 
                #    they usually append some str to the orginal executabe,
                #    and the final comm should not be truncated too.

                #for compatibility with some ugly qzone dispatch framework
                # with argv like: ./emotion_dispatch:../lib/libemotiondispatch.so
                # use 'emotion_dispatch' as prog in this case.
                if ":" in argv[0]:
                    tmpProg = argv[0]
                    argBin = basename(tmpProg[:tmpProg.find(':')])

                commTruncated = len(comm) == self.commMaxLen and len(comm) < len(argBin)
                if not commTruncated:
                    if comm == "java":
                        #some people tried to symlink java bin to app_name
                        #and made pkg framework to work with it
                        self.logger.debug("got java prog '%s'", args)
                        prog = argBin
                    else:
                        self.logger.debug("got prog in comm: %s", args)
                        prog = comm
                else:
                    self.logger.debug("got prog in argv: %s", args)
                    prog = argBin
            progLines = psMap.setdefault(prog, [])
            progLines.append(line)
        return psMap


            

    def takePsSnapshot(self, saveTo=""):
        psCmd = ['ps', '--sort=-pcpu','-e', '-ww', '-o', ",".join(self.psFields) ]
        exitcode, output = self.run(psCmd, shell=False)
        if exitcode != 0:
            self.logger.error("task ps snaphost failed:%s", output)
            return False
        self.psMap = self.buildPsMap(output)
        if saveTo:
            try:
                fout = open(saveTo, 'w')
                fout.write(output)
                fout.close()
            except Exception, e:
                self.logger.error("write ps snapshot to '%s':%s" , saveTo, e)


    def getProcNumEx(self, procName):
        """return a tuple of (procNum, psSnapshot)"""
        if not self.psMap:
            self.takePsSnapshot()
        procList = self.psMap.get(procName, [])
        procNum = len(procList)
        self.logger.info("service '%s' proc num:%d", procName, procNum)
        procSnap = self.psTitle + "\n" + "\n".join(procList)
        self.logger.info("\n%s", procSnap)
        return (procNum, procSnap)

    def getProcNum(self, procName):
        return self.getProcNumEx(procName)[0]

    def _sigNumber(self, signalName):
        try:
            sigNum = int(signalName)
        except ValueError:
            #not number
            if not signalName.startswith("SIG"):
                signalName = "SIG" + signalName
            try:
                sigNum = getattr(signal, signalName)
            except AttributeError:
                #use SIGKILL as default
                self.logger.warn("invalid signal '%s'", signalName)
                sigNum = signal.SIGKILL
        return sigNum

    def killPidWait(self, pids, signum, timeout):
        """kill pid in pids with signum, wait at most timeout second
        return: (result, errorMsg)
        
        """
        #send signal to all pids
        error = []
        for pid in pids:
            try:
                self.logger.info("kill pid %d", pid)
                os.kill(pid, signum)
            except OSError, e:
                if e.errno != errno.ESRCH:
                    msg = "kill pid %d: %s" %  (pid, e)
                    self.logger.error(msg)
                    error.append(msg)
        #if there's any error, just return
        if error:
            #"FATAL:" is used to tell caller don't try again
            error.insert(0, "FATAL:")
            return (False, "\n".join(error))
        #wait pids to die or until timeout
        start = time.time()
        pidsRemain = list(pids)
        while (time.time() - start < timeout):
            #make a shadow copy
            for pid in pidsRemain[:]:
                try:
                    os.kill(pid, 0)
                    self.logger.debug("pid %d still exists", pid)
                except OSError, e:
                    if e.errno == errno.ESRCH:
                        self.logger.info("pid %d exited", pid)
                        #remove killed process
                        pidsRemain.remove(pid)
            if pidsRemain: 
                time.sleep(0.004)
            else:
                return (True, "")
        return (False, "kill timed out")

    def killProc(self, procName, killSignal="KILL", killTimeout=11):
        self.logger.info("kill proc '%s' with signal %s", procName, killSignal)
        killSignal = self._sigNumber(killSignal)
        if not self.psMap:
            self.takePsSnapshot()
        procList = self.psMap.get(procName, [])
        pids = [ int(l.split()[0]) for l in procList ]
        #sort pid in order to kill parent process first
        #we assume that parent process has lower pid
        pids = sorted(pids)
        if not pids:
            return (True, "no pid running")
        return self.killPidWait(pids, killSignal, killTimeout)

    def pidfileCheck(self, keyword, pidfile):
	"""
	check if process with pid in 'pidfile' exists and has 'keyword' in argv
	return (True, "MSG") on success
	return (False, "MSG") on failure
	"""
	pid = 0
	try:
	    fp = open(pidfile)
	    pid = fp.read().strip()
	    fp.close()
	except IOError, e:
	    return (False, "can not read pidfile: %s" % e)
	try:
	    pid = int(pid)
	except ValueError, e:
	    return (False, "invalid pidfile '%s'" % pidfile)
	#check if pid exists in /proc filesystem
	procCmdline = "/proc/%d/cmdline" % pid
	if not os.path.isfile(procCmdline):
	    return (False, "process with pid %d not exists" % pid)
	cmdline = ""
	try:
	    fp = open(procCmdline)
	    cmdline = fp.read().replace('\0', ' ').strip()
	    fp.close()
	except IOError, e:
	    return (False, "failed to read argv of pid %d: %s" % (pid, e))
	if keyword in cmdline:
	    return (True, "proc '%s' exists, pid:%d" % (keyword, pid))
	else:
	    return (False, "pid %s exists but with argv '%s'" % (pid, cmdline))

    


if __name__ == "__main__":
    logging.basicConfig(format='[%(asctime)-15s] %(levelname)s %(message)s', level=logging.INFO)
    procUtil = ProcUtil()

    if len(sys.argv) < 3:
        print >>sys.stderr, "Usage: %s kill_app|get_proc_num app" % sys.argv[0]
        sys.exit(1)
    command = sys.argv[1]
    app = sys.argv[2]

    procUtil.takePsSnapshot()
    if command == "kill_app": 
        if len(sys.argv)-1 == 3:
            killSignal = sys.argv[3]
        else:
            killSignal = "SIGKILL"
        procUtil.killProc(app, killSignal)
    elif command == "get_proc_num":
        procNum = procUtil.getProcNum(app)
        print procNum
    else:
        print >>sys.stderr, "unknow command '%s'" % command
        sys.exit(1)
