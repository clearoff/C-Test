#!/bin/bash
mydir=$(cd $(dirname "$0") && pwd)
$mydir/pkgadmin.py reload "$1"
