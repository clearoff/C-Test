#!/usr/bin/env python
# encoding: utf8

import os,sys,time
import fcntl,errno
import socket,struct

def alert(msg, attrid="221525"):
    alert_cmd = '/usr/local/agenttools/agent/agentRepStr %s' % attrid
    msg = msg.replace("'","") #remove quote
    try:
        os.system("%s '%s' &> /dev/null" % (alert_cmd, msg))
        return True
    except os.error, e:
        print >>sys.stderr, "run cmd error:%s" % e
        return False

class LockException(Exception):
    pass


lock_dir = '/dev/shm'
if os.path.isdir(lock_dir) and os.stat(lock_dir).st_mode & 0777 == 0777:
    pass
else:
    lock_dir = '/tmp'
    
def lock(lock_name, timeout=0, mode=0600):
    """return a decorator which allow func to called only with lock held
    Params:
        lock_name:  the lock name of this operation
        timeout:   lock waiting timeout in second, if lock can't be acquired after
            timeout seconds, exception will be raised
            the value of 0 means fail immediately if can't acquire lock
            the value of None means wait for lock indefinitely.
            
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            #clear umask
            old_umask = os.umask(0)
            try:
                lock_file = os.path.join(lock_dir, '.%s.lck' % lock_name)
                lock_fd = os.open(lock_file, os.O_CREAT|os.O_WRONLY, mode)
                #restore umask
                os.umask(old_umask)
            except OSError, e:
                os.umask(old_umask)
                raise LockException("lock error:%s" % e)

            lock_flags = fcntl.LOCK_EX
            if timeout is not None:
                lock_flags |= fcntl.LOCK_NB

            start_time = time.time()
            while True:
                try:
                    fcntl.lockf(lock_fd, lock_flags)
                    #lock acquired
                    break
                except IOError, e:
                    if e.errno == errno.EAGAIN and time.time() < (start_time + timeout):
                        #sleep and try again
                        time.sleep(0.05)
                    else:
                        #maybe timeout or other error, throw it
                        raise LockException("lock error:%s" % e)
            try:
                return func(*args, **kwargs)
            finally:
                fcntl.lockf(lock_fd, fcntl.LOCK_UN)
        return wrapper
    return decorator

def readFile(path):
    fh = open(path)
    content = fh.read()
    fh.close()
    return content

def getIP(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:    
        return socket.inet_ntoa(fcntl.ioctl(
            s.fileno(),
            0x8915,  # SIOCGIFADDR
            struct.pack('256s', ifname[:15])
            )[20:24])
    except: 
        return ""

def getLanIP():
    """
    get lan ip use fake udp connection
    this does not really 'connect' to any server
    """
    #can be any routable address, 
    fakeDest = ("10.10.10.10", 53)
    lanIP = ""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(fakeDest)
        lanIP = s.getsockname()[0]
        s.close()
    except Exception, e:
        pass
        #print >>sys.stderr, e
    return lanIP

def getWanIP():
    """
    get lan ip use fake udp connection
    this does not really 'connect' to any server
    """
    #can be any routable address, 
    fakeDest = ("8.8.8.8", 53)
    wanIP = ""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(fakeDest)
        wanIP = s.getsockname()[0]
        s.close()
    except Exception, e:
        pass
        #print >>sys.stderr, e
    return wanIP

