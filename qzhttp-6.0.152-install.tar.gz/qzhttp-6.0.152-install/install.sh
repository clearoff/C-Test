#!/bin/sh
###file_ver=2.0.9
#  modified by xiaohanwang 20090820 : rpt_info
## add echo AUTOBAT for AOS install
## modified by marshalliu 2009-01-09
#create by leonlaili,2006-12-6
#pekinglin

export PATH=$PATH:/usr/bin:/usr/sbin:/sbin:/bin:.
#get script path
dir_pre=$(dirname $(which $0))


#p2p install
get_p2p_child(){

param_list=$1

local tmpfile="/tmp/pkgp2p_${instance_id}.log"
`curl -s --connect-timeout 3 --retry 3 -H "Host:pkg.isd.com" "http://10.130.84.26/p2pchild.php?parent=$ip_inner&task_id=$p2p_task_id">${tmpfile}`
log "get child rs:param_list= '${param_list}'";

while read ip i_id
    do
        
        
        if [[ -z "$ip" ]];then
            continue;
        fi
        
        
        log "bgein $ip p2p install: $ip $i_id '$param_list' $install_path"
        
        `nohup $dir_pre/p2p.sh $ip $i_id "$param_list" $install_path >/dev/null 2>&1 &`
    done < ${tmpfile}
    
    rm $tmpfile
}


#load data from init.xml
#param: <tab name>
get_config()
{
    if [ "$1" = "" ];then return 1;fi

    conf_file=$dir_pre/init.xml
    if [ ! -f $conf_file ];then return 1;fi

    conf_value=$dir_pre/`date +%s%N`${RANDOM}.tmp

    ## Todo: load config
    row1=`grep -n "^<$1>\$" $conf_file | awk -F: '{print $1}' | tail -n 1`
    row2=`grep -n "^</$1>\$" $conf_file | awk -F: '{print $1}' | tail -n 1`

    if [ "$row1" = "" -o "$row2" = "" ];then
        return 1
    fi

    if [ $row1 -gt $row2 ];then
        return 1
    fi

    head -n `expr $row2 - 1` $conf_file | tail -n `expr $row2 - $row1 - 1 ` > $conf_value
    ret=$conf_value
    return 0
}

#execute script in init.xml
#param: <tab name>
run_config()
{
    get_config $1
    if [ $? -eq 0 ];then
        . $ret
        rm $ret > /dev/null 2>&1
    fi
}

#update base info in init.xml
update_config()
{
    conf_file=$dir_pre/init.xml
    item=$1
    value=$2

    max_row=`grep -n "^</base_info>\$" $dir_pre/init.xml | awk -F: '{print $1}' | tail -n 1`
    if [ "$max_row" = "" ];then
        echo "Error: can not find item base_info"
        return 1
    fi
    
    item_row=`grep -n "^${item}=" $conf_file | awk -F: '{print $1}' | head -n 1`
    if [ "$item_row" = "" ];then
        echo "Error: can not find item $item"
        return 1
    fi  
    
    rows=`wc -l $conf_file | awk '{print $1}'`
    #lastRow=`tail -n 1 $conf_file`
    #rows=`grep -n "^${lastRow}\$" $conf_file | awk -F: '{print $1}' | head -n 1`
    if [ $item_row -ge $max_row ];then
        echo "Error: can not find item $item"
        return 1
    fi  
    
    tmp_file=$dir_pre/`date +%s%N`${RANDOM}.tmp
    
    head -n $(( $item_row -1 )) $conf_file > $tmp_file
    echo "${item}=\"${value}\"" >> $tmp_file 
    #tail -n $(( $rows - $item_row )) $conf_file >> $tmp_file
    sed "1,${item_row}d" $conf_file >> $tmp_file
    cp $tmp_file $conf_file
    rm $tmp_file 
}

# 读取参数
# 参数: 参数名 默认值
get_param()
{
    default_value=$2
    ret=""
    if [ "$default_value" != "" ];then
        echo -n "Please input $1 [$2] : "
        read ret
        if [ -z "${ret}" ];then
            ret=$default_value
        fi
        return
    fi 
    until [ "$ret" != "" ]
    do  
        echo -n "Please input $1 : "
        read ret
    done
}

#check current user
check_user()
{
    if [ "`whoami`" != "$user" ];then
        echo "Only $user can execute this script"
        errmsg="current user: $(whoami) do not match package user: $user"
        rpt_info
        exit 1
    fi
}

#add install log
log()
{
    log_file=${dir_pre}/install.log
    echo "[`date "+%Y-%m-%d %H:%M:%S"`] $*" | tee -a $log_file
}

#return boot file path
get_boot_path()
{
    mkdir -p `dirname $boot_path`
    if [ ! -f $boot_path ];then
        echo "#! /bin/sh" > $boot_path
        chmod +x $boot_path
    fi
    ret="$boot_path"
}

#print help information
print_help()
{
    ##todo: output help information here
    echo "Usage: install.sh [install_path]"
    echo "note: the application will be installed in install_path/app_name-app_version"
}

#check script parameters
check_params()
{
    local err_para=""
    ok="true"
    if [ "$install_base" = "" ];then
        ok="false"
        err_para="install_base"
    fi
    ##todo: add addition parameters checking statement here...
    if [ "$name" = "" ];then
        ok="false"
        err_para="name $err_para"
    fi

    if [ "$app_name" = "" ];then
        ok="false"
        err_para="app_name $err_para"
    fi

    if [ "$user" = "" ];then
        ok="false"
        err_para="user $err_para"
    fi
    
    if [ "$ok" != "true" ];then
        echo "Some of the parameters are invalid. para: $err_para"
        errmsg="config error, para: $err_para"
        rpt_info 
        print_help
        exit 1
    fi    
}

#check current environment
check_environment()
{
    ok="true"
    ##todo: add environment checking statment here
    #example: kernel,libary,relative application...
    
    if [ "$ok" = "true" ];then
        return
    else
        log "Sorry, the computer isn't fit for this application."
        log "Install failed"
        #print suggestion here       
        errmsg="check_environment error"
        rpt_info
        exit 1
    fi
}

#check old version of the application
check_old_version()
{
    if [ -d $install_path -a "$force_install" != "true" ];then
        if [ -d "$install_path" ];then
            log "Sorry, you have installed the same application yet"
            log "Directory $install_path exists,install failed"
            #if [ "$start_on_complete" = "true" ];then
            #    $install_path/admin/restart.sh all force
            #fi         
            errmsg="同名包已安装"
            rpt_info
            exit 1
        fi
    fi
}
check_valid_pkg()
{

    pkg_path=$1
    if [ -d $pkg_path -a -d "${pkg_path}/admin" -a -f "${pkg_path}/init.xml" ];then
        return 0
    else
        return 1
    fi
}


#get a setting from user
#parameters:    $1 setting name, required
#               $2 default value, optional
#return:            user input, get the value by variable "ret"
get()
{
    default_value=$2
    if [ "$default_value" != "" ];then
        echo -n "Please input $1 [$2] : "
        read ret
        if [ -z $ret ];then
            ret=$default_value
        fi
        return
    fi
    until [ "$ret" != "" ]
    do
        echo -n "Please input $1 : "
        read ret
    done
}

#get all setting from user
get_settings()
{
    ##todo: add statement to get settings here
    #example:
    #   get_setting name
    #   name=$ret
    #   get_setting company tencent
    #   company=$ret
    return 0
}

#confirm setting
get_confirm_setting()
{
    #remove this statement when use this function
    return 0
    
    ok=""
    until [ "$ok" = "y" ]
    do
        get_settings
        ##todo: output settings here
        #example:
        #   echo "Are those settings correct?"
        #   echo "  name        : $name"
        #   echo "  company     : $company"
        #   echo -n "[y/n]"
        read ok
    done
}

on_start()
{
    ##todo: add any statment you want when installation start
    #init install directory
    log "Install start"
    if [ ! -d "$install_path" ];then
        mkdir -p $install_path
        if [ $? -ne 0 ];then
            log "Can not create directory: $install_path"
            log "Install failed"
            errmsg="Can not create $install_path"
            rpt_info
            exit 1
        fi
        log "Create directory: $install_path"
    fi
    chmod 755 $install_path

    run_config "install_on_start"

    return 0
}

#update external file
update_external_file()
{
    #复制文件前自动把现网的外部文件更新到安装包
    get_config "external_file"
    retValue=$?
    if [ $retValue -ne 0 ];then
        log "External file config get fail: $retValue"
        return $retValue
    fi
    conf_tmp=$ret
    if [ ! -f "$conf_tmp" ];then
        log "External file config not found"
        return $retValue
    fi
    
    while read file;do
        if [ -f "$install_path/$file" ];then
            target_dir=`dirname "$dir_pre/$file"`
            if [ ! -d "$target_dir" ];then
                mkdir -p "$target_dir"
            fi
            
            cp -a "$install_path/$file" "$dir_pre/$file"
            if [ $? -ne 0 ]; then
                log "Update external file failed: $install_path/$file"
                log "Install failed"
                errmsg="update external file failed ;cp -a $install_path/$file $dir_pre/$file"
                rpt_info
                exit 1
            else
                log "Update external file success: $install_path/$file"
            fi
        fi
    done < $conf_tmp
}

#mode转化为0644格式
function get_num_mode()
{
    local str_mode=$1
    mode='0'
    temp=0
    j=0
    for((i=1;i<10;i++))
    do
        s=${str_mode:$i:1}
        if [ "$s" == "r" ];then
            (( temp+=4 ))
        elif [ "$s" == "w" ];then
            (( temp+=2 ))
        elif [ "$s" == "x" ];then
            (( temp+=1 ))
        fi
        (( j+=1 ))
        if [ $j -eq 3 ];then
            mode="${mode}$temp"
            temp=0
            j=0
        fi
    done
    echo $mode
}

#递归复制目录或者文件(使用install)
function install_cp()
{
    local source=$1
    local dist=$2
    local num=$3
    ls -l --time-style=long-iso $source > ./file_list.$$.$3
    while read mode linkCount user group size day time file tail
    do
        if [ ${#mode} -eq 10 ] || [ ${#mode} -eq 11 ];then
			echo $mode | grep -q ^d
			if [ $? -eq 0 ];then
				mkdir -p $dist/$file
				num_mode=`get_num_mode $mode`
				chmod $num_mode $dist/$file
				install_cp $source/$file $dist/$file "${3}1"
			else
				echo $mode | grep -q ^-
				if [ $? -eq 0 ];then
					num_mode=`get_num_mode $mode`
					install -p -m $num_mode $source/$file $dist/
				else
					cp -ar $source/$file $dist/
				fi
			fi            
        fi

        local retval=$?
    done < ./file_list.$$.$3
    rm ./file_list.$$.$3 > /dev/null 2>&1
    if [ "x$3" = "x" ];then
        rm $dist/file_list.$$.$3 >/dev/null 2>&1
    fi

    return $retval
}

#copy files
copy_files()
{
    log "Copying files..."
    ##todo: add copy statement here
    #example:

    if [ "$force_install" = "true" -a -f "$install_path/admin/stop.sh" ];then
        $install_path/admin/stop.sh all
    fi

    # cp -a $dir_pre/* $install_path/
    install_cp $dir_pre/ $install_path/
    if [ $? -ne 0 ]; then
       log "install file failed: $install_path"
       log "Install failed"
       errmsg="install file failed ;install_cp ${dir_pre}/* ${install_path}/"
       rpt_info
       exit 1
    fi

    rm $install_path/install.sh
    rm $install_path/p2p.sh
    rm $install_path/pkg_install_root.exp
    rm $install_path/pkg_upload.exp
    rm $install_path/test_connect.exp
    
    rm $install_path/install.log
    rm $install_path/before_install.sh > /dev/null 2>&1
    rm $install_path/after_install.sh > /dev/null 2>&1

    ##todo: create log folder
    mkdir -p $log_dir 2>&1
    if [ "$log_dir" != "$install_path/log" ];then
        chown ${user}:users $log_dir >/dev/null 2>&1
        chmod 775 $log_dir >/dev/null 2>&1
        rm -rf $install_path/log
        ln -s $log_dir $install_path/log
    fi
}

#complie source code and install
complie_make()
{
    ##todo: add complie and make statement when needed
    
    ##Load make
    run_config "make"

    return 0
}

#substitute place holders in the files
substitute()
{
    #substitute the default place holders of files in admin
    log "Substitute the place holders of files in admin"

    subs_file="$install_path/admin/data/subs.lst"
    
    touch $subs_file

    get_config "substitute"
    while read file_tmp tail
    do
       ls -d $install_path/$file_tmp >> $subs_file 2>/dev/null
    done < $ret
    rm $ret

    while read result tail
    do
        if [ ! -f "$result" ];then continue ;fi

        #check text file
        #echo "`/usr/bin/file -b $result | awk -F, '{print $1}'`" | grep " text" > /dev/null
        /usr/bin/file -b $result | grep -w "text" > /dev/null
        if [ $? -ne 0 ];then continue;fi

        LANG="" LC_CTYPE="" sed -e "s:#INSTALL_PATH:$install_path:g" \
            -e "s:#INSTALL_BASE:$install_base:g" \
            -e "s:#IP_INNER:$ip_inner:g" \
            -e "s:#IP_OUTER:$ip_outer:g" \
            -e "s:#IP_VIP:$ip_vip:g" \
            $result > $install_path/subs.tmp
        cp $install_path/subs.tmp "$result"
    done < $subs_file
    rm $subs_file
    rm $install_path/subs.tmp
}

#create link needed
link_files()
{
    mkdir -p $link_dir 2>/dev/null
    rm $link_dir/$name 2>/dev/null
    ln -s $install_path "$link_dir/$name" 2>/dev/null
    if [ $? -eq 0 ];then
        log "Create link $link_dir/$name success"
    else
        log "Create link $link_dir/$name failed"
    fi
    ##todo: add addition link statment here
    tmp=`pwd`

    #Load link script
    run_config "link"
    
    cd $tmp
}

#change files owner or popedom
update_popedom()
{
    chmod ug+x $install_path/admin/*.sh >/dev/null 2>&1
    chmod 777 $install_path/admin/data/tmp >/dev/null 2>&1
    chmod ug+x $install_path/bin/* >/dev/null 2>&1
    chown $user:users -R $install_path
    if [ $? -eq 0 ];then
        log "Change application files owner success"
    else
        log "Change application files owner failed"
    fi
    ##todo: add addition statement here
}

#config system
configure()
{
    ##todo: add system config statment here
    get_boot_path
    boot_file=$ret
    if [ $auto_start -eq 1 ];then
        grep "$install_path/admin/start.sh" $boot_file > /dev/null
        if [ $? -ne 0 ];then
            echo "#start $name" >> $boot_file 2>/dev/null
            echo "$install_path/admin/start.sh" >> $boot_file 2>/dev/null
            if [ $? -eq 0 ];then
                log "Set auto start when boot success"
            else
                log "Set auto start when boot failed"
            fi
        else
            log "Set auto start when boot success"
        fi
    fi
    return 0
}

#on complete
on_complete()
{
    ##todo: add any statment you want when installation complete

    run_config "install_on_complete"

    return
}

#report package infomation
rpt_info()
{    
    now_version=`tail -n 1 $install_path/admin/data/version.ini | awk '{print $3}'`
    if [ -f $install_path/admin/data/source.ini ];then
        src_path=`head -n 1 $install_path/admin/data/source.ini`
    else
        src_path="x"
    fi
    
    print_result "${errmsg}"    
    
    
    if [ -f /etc/occonf.ini ];then
        rpt_info2
        return $?
    fi 
    report_ip=10.130.84.27:80
    #url_head="http://$report_ip/install_rpt.php"
    #response_file="/tmp/.install_report.tmp.$$"
    #wget_options="-T 10 -O $response_file --connect-timeout=0"
    #wget_options="-O $response_file --connect-timeout=0"
    #wget_options='-T5 -t1 -O /dev/null --header="Host:pkg.isd.com"'
    sleep 2
    #local ret=`curl -s -H "Host:pkg.isd.com" "http://$report_ip/install_rpt.php?pkg_path=${src_path}&ip=${ip_inner}&install_path=${install_path}&user=${user}&pkg_ver=${now_version}&errmsg=$errmsg&name=$name&error_app_list=${error_app_list}&instance_id=${instance_id}"`
   local ret=`curl -s --connect-timeout 3 --retry 3 -H "Host:pkg.isd.com" "http://$report_ip/install_rpt.php?pkg_path=${src_path}&ip=${ip_inner}&install_path=${install_path}&user=${user}&pkg_ver=${now_version}&name=$name&instance_id=${instance_id}" -d "&errmsg=$errmsg&error_app_list=$error_app_list" `
}

print_result()
{
    local result_msg=$1
    op="install"
    echo
    echo
    echo "result%%${ip_inner}%%${name}%%${install_path}%%${op}%%${result_msg}%%${error_app_list}%%"
    echo
}

rpt_info2()
{
    source /etc/occonf.ini
    if [ "x" = "x${wgetproxy1}" ];then return 0; fi
    report_ip=${wgetproxy1}
    url_head="http://${wgetproxy1}/cgi-bin/proxy.cgi?octype=pkg_install"
    #wget_options="-O /dev/null --connect-timeout=0"
    wget_options="-T5 -t1 -O /dev/null"
    
    now_version=`tail -n 1 $install_path/admin/data/version.ini | awk '{print $3}'`
    if [ -f $install_path/admin/data/source.ini ];then
        src_path=`head -n 1 $install_path/admin/data/source.ini`
    else
        src_path="x"
    fi  

    argv_list="pkg_path=${src_path}&ip=${ip_inner}&install_path=${install_path}&user=${user}&pkg_ver=${now_version}&errmsg=$errmsg&name=$name&error_app_list= ${error_app_list}&instance_id=${instance_id}"
    wget $wget_options "${url_head}&${argv_list}" > /dev/null 2>&1
}

#check whether installation success?
check_installation()
{
    ok="true"
    ##todo: add check statement here

    run_config "check_installation"
    
    if [ "$ok" = "true" ];then
        log "Install complete."
        errmsg="success"
        if [ "$start_on_complete" = "true" ];then
            start_app
        fi
        rpt_info
    else
        log "Install failed."
        errmsg="check_installation fail"
        rpt_info
    fi
    mv $dir_pre/install.log $log_dir
}

#start the application
start_app()
{
    log "Start application"
    
    cat $install_path/init.xml | grep '^is_shell' | head -n 1 | grep -q 'true'
    if [ $? -eq 0 ];then 
        $install_path/admin/start.sh all force >/dev/null 2>&1
        return 0; 
    fi

    if [[ -f $install_path/admin/version.txt ]]; then
        #新admin逻辑
        cd $install_path/admin
        ./start.sh all force
        result=$?
        if [[ $result -ne 0 ]]; then
            log "app start failed"
            err_count=$(( $err_count + 1 ))
            if [ "x${error_app_list}" = "x" ];then
                error_app_list="all"
            else
                error_app_list="${error_app_list}, all"
            fi
            if [ "x${error_app_list}" != 'x' ];then
                error_app_list="${error_app_list} start failed"
            fi
        fi
    else
        $install_path/admin/start.sh all force >/dev/null 2>&1
        # 检查进程
        for app in `echo "$app_name" | sed -e "s/:[^ ]*//g"`
        do
            #ps -f -C $app | fgrep -w $app >/dev/null
            local num=`get_proc_num $app`
            if [ $num -gt 0 ];then
                log "$app start success"
            else
                err_count=$(( $err_count + 1 ))
                if [ "x${error_app_list}" = "x" ];then
                    error_app_list="${app}"
                else
                    error_app_list="${error_app_list},${app}"
                fi
                log "$app start fail"
            fi
        done
        if [ "x${error_app_list}" != 'x' ];then
            error_app_list="${error_app_list} start fail"
        fi
    fi
}

get_proc_num()
{
    local app_name=$1
    local num=`ps -f -C $app_name | fgrep -w $app_name | wc -l`
    if [ $num -eq 0 ];then
        num=`pgrep -f '^((\S*/bin/)?(perl|python|php|sh|bash) )?(\S+/)?'$app_name'($| .+$)'|wc -l`
        if [ $num -eq 0 ];then
            num=`pgrep -f '^java (.*)? (\S+/)?'$app_name'($| .+$)'|wc -l`
        fi
    fi
    echo $num
}

# renew_app_name
renew_app_name()
{
    run_config "base_info"
    for app_info in $app_list; do
        old_app=`echo $app_info | awk -F":" '{print $1}'`
        new_app=`echo $app_info | awk -F":" '{print $2}'`
        if [ -z "$old_app" -o -z "$new_app" ]; then
            continue
        fi
        echo $app_name | grep -q -w "$old_app"
        if [ $? -ne 0 ]; then
            log "process name $old_app not exist,can not modify"
            continue
        fi
        log "modify app_name $old_app to $new_app"
        app_name2=`echo $app_name | sed "s/\<$old_app\>/$new_app/"`
        if [ "$app_name2" ]; then
            app_name="$app_name2"
        fi

        log "modify $old_app to $new_app in start tag"
        cat $dir_pre/init.xml | sed "/<start>/,/<\/start>/ s/${old_app}/${new_app}/" > $dir_pre/init.xml.$$.xx
        cat $dir_pre/init.xml.$$.xx | grep -q "app_name"
        if [ $? -ne 0 ]; then
            rm $dir_pre/init.xml.$$.xx > /dev/null 2>&1
            log "modify $old_app to $new_app in start tag failed"
        else
            mv $dir_pre/init.xml.$$.xx $dir_pre/init.xml
        fi

    done
    update_config 'app_name' "$app_name"
    run_config "base_info"
}

# link app list
link_app()
{
    local dirtmp=`pwd`
    for app_info in $app_list; do
        old_app=`echo $app_info | awk -F":" '{print $1}'`
        new_app=`echo $app_info | awk -F":" '{print $2}'`
        if [ -z "$old_app" -o -z "$new_app" ]; then
            continue
        fi
        cd $install_path/bin
        if [ ! -f $old_app ];then continue; fi
        ln -s $old_app $new_app > /dev/null 2>&1
    done
    cd $dirtmp
}

####### Framwork variables begin  ########

##Update config from params




##Load base info
run_config "base_info"

for((i=1;i<=$#;i++))
do
    arg=`echo ${!i}`
    echo $arg | grep -q '='
    if [ $? -ne 0 ];then continue; fi
    xname=`echo $arg|awk -F "=" '{print $1}'`
    xvalue=`echo $arg|sed "s/${xname}=//"|tr -d "\r"`
    eval "${xname}=\${xvalue}"
    if [ "x${xname}" != "xrename_list" -a "x${xname}" != "xinstance_id" -a "x${xname}" != "xstart_on_complete" -a "x${xname}" != "xp2p_task_id" ];then
        update_config "${xname}" "${xvalue}"
    fi
done

if [ "x${rename_list}" != "x" ]; then
    new_name=`echo "${rename_list}" | awk -F"#" '{print $1}'`
    name=$new_name
    if [ "$new_name" ]; then
        update_config 'name' "$new_name"
    fi
    app_list=`echo "${rename_list}" | awk -F"#" '{print $2}' | sed 's|,| |g'`
    if [ "x${app_list}" != "x" ]; then
        renew_app_name
    fi
fi
run_config "base_info"
#install directory
if [ "$install_base" = "" ];then
    install_base="/usr/local/services"
fi

if [ "$install_path" = "" ];then
    if [ -z "$version" ];then
        install_path="$install_base/$name"
    else
        if [ "${no_version}x" == "1x" ];then
            install_path="$install_base/$name"
        else
            install_path="$install_base/$name-$version"
        fi
    fi
    update_config 'install_path' "$install_path"
fi

if [ "$log_dir" = "" ];then
    log_dir="$install_path/log"
fi
link_dir="$HOME/services"

#old version
if [ -L $link_dir/$name ];then
    old_ver=`ls -l $link_dir/$name | awk -F\> '{print $2}' | sed -e "s:^[\t ]*::"`
else
    old_ver=""
fi

####### Framwork variables end    ########

####### Custom variables begin  ########
##todo: add custom variables here
ip_outer=`/sbin/ifconfig eth0 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
if [ "${ip_outer}x" = "x" ]; then
    ip_outer=`/sbin/ifconfig eth0 2>/dev/null | grep "inet" | grep -v "inet6" | awk '{print $2}'`
fi
ip_inner=`/sbin/ifconfig eth1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
if [ "${ip_inner}x" = "x" ];then
   ip_inner=`/sbin/ip route|egrep 'src 172\.|src 10\.|src 100\.'|awk '{print $9}'|grep -v '^$'|head -n 1`
fi
ip_vip=`/sbin/ifconfig eth1:1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
####### Custom variables end    ########

###### Main Begin ########

if [[ ! -z "$p2p_task_id" ]];then
           get_p2p_child "$*"
fi



if [ "$1" = "--help" ];then
    print_help
    exit
fi

check_user
check_params
check_environment
check_old_version
get_confirm_setting
on_start
update_external_file
copy_files
complie_make
substitute
link_files
link_app
configure
update_popedom
on_complete
log "Build files md5sum"
$install_path/admin/md5sum.sh build
check_installation
###### Main End   ########
