#! /bin/sh

export PATH=$PATH:/usr/bin:/usr/sbin:/sbin:/bin:.
cur_path=$(dirname $(which $0))
cd $cur_path
report_ip=10.130.84.26
rpt_info()
{    
   now_version=`tail -n 1 $cur_path/admin/data/version.ini | awk '{print $3}'`
    if [ -f $cur_path/admin/data/source.ini ];then
        src_path=`head -n 1 $cur_path/admin/data/source.ini`
    else
        src_path="x"
    fi
	
	
	local name=`basename $src_path`
	
  
    #report_ip=10.166.224.35
	
    url_head="http://$report_ip/install_rpt.php"
    #response_file="/tmp/.install_report.tmp.$$"
    #wget_options="-T 10 -O $response_file --connect-timeout=0"
    #wget_options="-O $response_file --connect-timeout=0"
    #wget_options='-T5 -t1 -O /dev/null --header="Host:pkg.isd.com"'
    local ret=`curl -s -H "Host:pkg.isd.com" "http://$report_ip/install_rpt.php?pkg_path=${src_path}&ip=${rsIp}&install_path=${install_path}&user=${user}&pkg_ver=${now_version}&errmsg=$errmsg&name=$name&error_app_list=${error_app_list}&instance_id=${instance_id}&status=$errno"`
   
    #`wget $wget_options "${url_head}?pkg_path=${src_path}&ip=${rsIp}&install_path=${install_path}&pkg_ver=${now_version}&errmsg=$errmsg&name=$name&error_app_list=&instance_id=${instance_id}&status=$errno" > /dev/null 2>&1`
	
}
getPasswd(){
local i_id=$1
local ret=''
ret=`curl -s -H "Host:pkg.isd.com" "http://$report_ip/getrsPwd.php?instance_id=${i_id}"`
echo $ret
return 0
}
function check_pkg()
{
    local pkg_path=$1
    if [[ ! -d $pkg_path || ! -f $pkg_path/init.xml || ! -f $pkg_path/install.sh || ! -d $pkg_path/admin || ! -f $pkg_path/admin/data/version.ini || ! -f $pkg_path/admin/data/source.ini ]];then return 1; fi
    cat $pkg_path/init.xml | grep -q '^name='
    return $?
}

# check_install_pkg
# ��鰲װ��������
function check_install_pkg()
{
    check_pkg $cur_path
    if [ $? -ne 0 ];then 
        errno=2
        errmsg="%B0%B2%D7%B0%B0%FC%BC%EC%B2%E9%CA%A7%B0%DC"
      
        return $errno
    fi
    return 0
}


function test_connect()
{
    
	local ip=$1
	local user=$2
	local passwd=$3

	/usr/bin/netcat -zn -w4 ${ip} 36000
	if [ $? -ne 0 ];then
		echo "$ip $user $passwd 1$?" >> /tmp/xxxx.tom
		return 1
	fi

	#clear ssh key
	
	if [[ -f ~/.ssh2/hostkeys/key_36000_${ip}.pub ]];then
		rm -f ~/.ssh2/hostkeys/key_36000_${ip}.pub
	fi
	$cur_path/test_connect.exp "$ip" "$user" "$passwd" > /dev/null 2>&1
	if [ $? -ne 0 ];then
		
		return 2
	fi
	return 0
	
}	
	
function do_upload()
{
    
  
    $cur_path/pkg_upload.exp "$rsIp" "root" "$passwd" "$pkg_user" "$cur_path" "${remote_dir_name}" > /dev/null
    local func_result=$?
    if [ $func_result -ne 0 ];then
       return 1
    fi
    return $func_result
}
function do_install()
{
    local pkg_path=$cur_path
    cat $pkg_path/install.sh | grep -q '###file_ver=2.0.9'
    if [ $? -eq 0 ];then
		$cur_path/pkg_install_root.exp "$rsIp" "root" "$passwd" "$pkg_user" "${remote_dir_name}" "$param_list" > /dev/null # "$param_list"һ��Ҫ��˫����:���ܴ��ڶ�������հ׷��ָ�,ĿǰӦ�ö����ߵ�����߼�
    else
        $cur_path/pkg_install_root.exp "$rsIp" "root" "$passwd" "$pkg_user" "${remote_dir_name}" ""  > /dev/null
    fi
	
	
}
	



######

rsIp=$1
instance_id=$2
param_list=$(echo $3 | sed "s/instance_id=[0-9]\{1,\}/instance_id=$2/g")
install_path=$4

remote_dir_name=$(basename $cur_path)
passwd=`getPasswd $instance_id`

if [ -z $passwd ];then
	sleep 1
	passwd=`getPasswd $instance_id`
	if [ -z $passwd ];then
		
		errno=1000
		errmsg="%CE%DEroot%C3%DC%C2%EB"
		
		rpt_info
		exit
	fi
fi

check_install_pkg
exit_code=$?
if [ $exit_code -ne 0 ];then
  
   rpt_info
   exit
fi


#pkg_userʵ�ʰ����û�
if [[ -z $pkg_user ]];then
    cat $cur_path/init.xml | grep '^user' | head -n 1 > $$.tmp
    source $$.tmp
    pkg_user=$user
    rm $$.tmp
fi

test_connect "$rsIp" "root" "$passwd" > /dev/null 2>&1

exit_code=$?
if [ $exit_code -ne 0 ];then
	sleep 5
	test_connect "$rsIp" "$passuser" "$password" > /dev/null 2>&1
	exit_code=$?
	if [ $exit_code -ne 0 ];then
		case ${exit_code} in
		1)
			errno=1003
			errmsg="%D6%F7%BB%FA%B2%BB%BF%C9%B4%EF.."
			;;
		2)
			errno=1001
			errmsg="root%C3%DC%C2%EB%B4%ED%CE%F3.."
			;;
		*)
			error=1010
			errmsg="%C1%AC%BD%D3%B4%ED%CE%F3.."
			;;
		esac
		
	
		rpt_info
		exit
	fi
fi

do_upload
exit_code=$?

if [ $exit_code -ne 0 ];then
   
    errno=1002
    errmsg='%C9%CF%B4%AB%B0%FC%CA%A7%B0%DC'
   rpt_info
   exit;
fi


do_install


